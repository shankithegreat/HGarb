const express = require('express');
const bodyParser = require('body-parser');
const crypto = require('crypto');
const sqlite3 = require('sqlite3').verbose();
const cors = require('cors'); // Import the cors package


const app = express();
const port = 3000; // Set your desired port
//const db = new sqlite3.Database('mydatabase.db');

// db.serialize(() => {
//     db.run(`
//       CREATE TABLE IF NOT EXISTS hashed_data (
//         id INTEGER PRIMARY KEY,
//         BrowserData TEXT,
//         Fingerprint TEXT,
//         UserAgent TEXT,
//         UserAgentLowerCase TEXT,
//         Browser TEXT,
//         BrowserVersion TEXT,
//         BrowserMajorVersion TEXT,
//         IE TEXT,
//         Chrome TEXT,
//         Firefox TEXT,
//         Safari TEXT,
//         Opera TEXT,
//         Engine TEXT,
//         EngineVersion TEXT,
//         OS TEXT,
//         OSVersion TEXT,
//         Windows TEXT,
//         Mac TEXT,
//         Linux TEXT,
//         Ubuntu TEXT,
//         Solaris TEXT,
//         Device TEXT,
//         DeviceType TEXT,
//         DeviceVendor TEXT,
//         CPU TEXT,
//         Mobile TEXT,
//         MobileMajor TEXT,
//         MobileAndroid TEXT,
//         MobileOpera TEXT,
//         MobileWindows TEXT,
//         MobileBlackBerry TEXT,
//         MobileIOS TEXT,
//         Iphone TEXT,
//         Ipad TEXT,
//         Ipod TEXT,
//         ScreenPrint TEXT,
//         ColorDepth TEXT,
//         CurrentResolution TEXT,
//         AvailableResolution TEXT,
//         DeviceXDPI TEXT,
//         DeviceYDPI TEXT,
//         Plugins TEXT,
//         MimeTypes TEXT,
//         Font TEXT,
//         Fonts TEXT,
//         LocalStorage TEXT,
//         SessionStorage TEXT,
//         Cookie TEXT,
//         TimeZone TEXT,
//         Language TEXT,
//         SystemLanguage TEXT,
//         clientip1 TEXT,
//         clientip2 TEXT,
//         network TEXT,
//         version TEXT,
//         city TEXT,
//         region TEXT,
//         region_code TEXT,
//         country TEXT,
//         country_name TEXT,
//         country_code TEXT,
//         country_code_iso3 TEXT,
//         country_capital TEXT,
//         country_tld TEXT,
//         continent_code TEXT,
//         in_eu TEXT,
//         postal TEXT,
//         latitude TEXT,
//         longitude TEXT,
//         geotimezone TEXT,
//         utc_offset TEXT,
//         country_calling_code TEXT,
//         currency TEXT,
//         currency_name TEXT,
//         languages TEXT,
//         country_area TEXT,
//         country_population TEXT,
//         asn TEXT,
//         org TEXT
//       )
//     `);
// });

// db.close();

app.use(bodyParser.json());
app.use(cors());

app.post('/store', (req, res) => {
    const inputData = req.body;
    const db = new sqlite3.Database('mydatabase.db');

    // Hash each individual parameter and store them in the SQLite database
    const hashedData = {};
    const placeholders = Object.keys(inputData).map(() => '?').join(',');
    const values = Object.values(inputData).map(value => crypto.createHash('sha256').update(value).digest('hex'));
    const checkQuery = `SELECT * FROM hashed_data WHERE clientip1 = '${crypto.createHash('sha256').update(inputData.clientip1).digest('hex')}';`;
    console.log(checkQuery);
    //${crypto.createHash('sha256').update(inputData.clientip1).digest('hex')}
    db.get(checkQuery, (err, row) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }

        if (row) {
            const updateQuery = `UPDATE hashed_data SET ${Object.keys(inputData).map(key => `${key} = '${crypto.createHash('sha256').update(inputData[key]).digest('hex')}'`).join(', ')}
            WHERE clientip1 = '${crypto.createHash('sha256').update(inputData.clientip1).digest('hex')}';`;
            console.log(updateQuery);
            db.run(updateQuery, function (err) {
                if (err) {
                    console.error(err.message);
                    res.status(500).json({ error: 'Error updating data' });
                } else {
                    console.log(`Data updated`);
                    res.status(200).json({ message: 'Data updated successfully' });
                }
            });
        }
        else {
            db.run(`
    INSERT INTO hashed_data (${Object.keys(inputData).join(', ')})
    VALUES (${placeholders})
  `, values, function (err) {
                if (err) {
                    console.error(err.message);
                    res.status(500).json({ error: 'Error storing data' });
                } else {
                    console.log(`Data stored with ID: ${this.lastID}`);
                    res.status(200).json({ message: 'Data stored successfully' });
                }
            });
        }
    });





    db.close();
});

app.listen(port, () => {
    console.log(`API server is running on port ${port}`);
});